MARGAYA PRESS KIT
=================

Margaya is an open-source project management platform for teams that want
clear ownership without heavy process. Plan work on boards, lists,
spreadsheets, calendars and Gantt charts, write docs beside the tasks, and
connect your tools through a REST API and MCP. Run it on your own server,
free and open source under the GNU AGPL-3.0.

Website     https://margaya.app
Press page  https://margaya.app/press
GitHub      https://github.com/manu14357/Margaya
Licence     AGPL-3.0, with a commercial licence available


ABOUT MARGAYA
-------------

Margaya is an open-source project management platform built for teams that
want to plan and ship work without the tool becoming a job of its own. Tasks
move through board, list, spreadsheet, calendar and Gantt views of the same
data. Cycles, modules, estimates and an intake inbox are there when a team
needs planning, and stay out of the way when it doesn't. Teams write docs
together next to their tasks, collect requests on public boards, and follow
progress with analytics and an audit log. A REST API with an OpenAPI
description, webhooks, an MCP server and integrations with GitHub, Gitea,
Slack, Discord and others connect Margaya to the rest of a team's tools. The
interface is available in 20 languages. Margaya is released under the GNU
AGPL-3.0, with a commercial licence for use without its conditions, and runs
on a single server with Docker, or on Kubernetes with Helm.


WHAT'S INSIDE
-------------

01-logos/
  margaya-wordmark-dark.svg / .png   For light backgrounds
  margaya-wordmark-light.svg / .png  For dark backgrounds
  margaya-icon.svg                   SVG, scales to any size
  margaya-icon-512.png               PNG, 512 x 512

02-product/
Real Margaya screens with fictional demo data, 3456 x 2000 pixels, light
theme before dark:
  01-margaya-board-light.png
  01-margaya-board-dark.png
  02-margaya-list-light.png
  02-margaya-list-dark.png
  03-margaya-spreadsheet-light.png
  03-margaya-spreadsheet-dark.png
  04-margaya-calendar-light.png
  04-margaya-calendar-dark.png
  05-margaya-gantt-light.png
  05-margaya-gantt-dark.png
  06-margaya-task-light.png
  06-margaya-task-dark.png
  07-margaya-page-light.png
  07-margaya-page-dark.png
  08-margaya-cycles-light.png
  08-margaya-cycles-dark.png
  09-margaya-analytics-light.png
  09-margaya-analytics-dark.png
  10-margaya-inbox-light.png
  10-margaya-inbox-dark.png
  11-margaya-home-light.png
  11-margaya-home-dark.png

03-brand/
  brand-colors.txt   Theme colours as hex, and the typefaces


USAGE GUIDELINES
----------------

Short and long descriptions, logos, screenshots, colours and type, ready for
articles, videos and talks. Everything in this kit may be used for editorial
coverage of Margaya.

Please do:
- Use the dark wordmark on light backgrounds and the light wordmark on dark
  ones.
- Leave clear space around the logo at least as wide as the icon's ears.
- Write the name as "Margaya", with a capital M, in running text.
- Link to margaya.app or the GitHub repository when you mention the project.

Please don't:
- Stretch, rotate, outline or add effects to the logo.
- Recolour the logo, or place it on busy images where it loses contrast.
- Suggest that the Margaya maintainers endorse a product, service or
  opinion.
- Edit screenshots to show features that Margaya doesn't have.

Margaya is built in the open, so the maintainers answer on GitHub. Start a
discussion for interviews and questions about the project, or open an issue
if something in this kit is missing or out of date.
